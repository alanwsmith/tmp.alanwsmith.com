#!/usr/bin/python
# -*- coding: utf-8 -*-
# pylint: disable=invalid-name
"""Redeem script to redeem rewards for a cost for users"""
#---------------------------------------
# Libraries and references
#---------------------------------------
import json
import os
import re
import copy
import time
import codecs
import threading
#---------------------------------------
# [Required] Script information
#---------------------------------------
ScriptName = "Time Master"
Website = "https://www.twitch.tv/must13"
Creator = "Must13"
Version = "1.0.4"
Description = "Custom Parameters $wait() - $ucd() - $cd() - $to() - see Readme for examples."
#---------------------------------------
# Versions
#---------------------------------------
""" 
1.0.4 - Every chatbot's parameters And other scripts' parameters are now compatible with the $wait() parameter, they will work but won't be delayed, only their chat response will be.

1.0.3 - Fixed $cd()/$ucd() when used in a multi lines command's response

1.0.2 - added $wait() to replace $newmessage()

1.0.1 - $to() will not force the rest of the message to be sent to stream chat anymore
      - $to() will now respect the delay set in $newmessage()

1.0.0 - Initial Release
"""
#---------------------------------------
# Variables
#---------------------------------------
settingsFile = os.path.join(os.path.dirname(__file__), "settings.json")
#---------------------------------------
# Classes
#---------------------------------------
class Settings:
    """" Loads settings from file if file is found if not uses default values"""

    # The 'default' variable names need to match UI_Config
    def __init__(self, settingsFile=None):
        if settingsFile and os.path.isfile(settingsFile):
            with codecs.open(settingsFile, encoding='utf-8-sig', mode='r') as f:
                self.__dict__ = json.load(f, encoding='utf-8-sig')

        else: #set variables if no custom settings file is found
            self.CooldownToggleResp = True
            self.NoCooldownForCaster = False
            self.OnCooldownResp = "$user $command is still on cooldown for $cooldown seconds."
            self.OnUserCooldownResp = "$user $command is still on user cooldown for $cooldown seconds."

    # Reload settings on save through UI
    def ReloadSettings(self, data):
        """Reload settings on save through UI"""
        self.__dict__ = json.loads(data, encoding='utf-8-sig')
        return

    # Save settings to files (json and js)
    def SaveSettings(self, settingsFile):
        """Save settings to files (json and js)"""
        with codecs.open(settingsFile, encoding='utf-8-sig', mode='w+') as f:
            json.dump(self.__dict__, f, encoding='utf-8-sig')
        with codecs.open(settingsFile.replace("json", "js"), encoding='utf-8-sig', mode='w+') as f:
            f.write("var settings = {0};".format(json.dumps(self.__dict__, encoding='utf-8-sig')))
        return

#---------------------------------------
# Settings functions
#---------------------------------------
def ReloadSettings(jsondata):
    """Reload settings on Save"""
    # Reload saved settings
    MySet.ReloadSettings(jsondata)
    # End of ReloadSettings

def SaveSettings(self, settingsFile):
    """Save settings to files (json and js)"""
    with codecs.open(settingsFile, encoding='utf-8-sig', mode='w+') as f:
        json.dump(self.__dict__, f, encoding='utf-8-sig')
    with codecs.open(settingsFile.replace("json", "js"), encoding='utf-8-sig', mode='w+') as f:
        f.write("var settings = {0};".format(json.dumps(self.__dict__, encoding='utf-8-sig')))
    return

#---------------------------------------
# [Required] functions
#---------------------------------------
def Init():
    """data on Load, required function"""
    global MySet
    global RegTo
    global RegNewmessage
    global RegCD
    global RegUCD
    global RegWait
    global destroy
    global response
    global counter
    counter = 0
    response = ""
    destroy = False
    RegTo = re.compile(r"(?:\$to\([\ ]*(?P<username>[^\"\']+)"
                    r"[\ ]*\,[\ ]*(?P<duration>[^\"\']*)[\ ]*\))", re.U)
    RegNewmessage = re.compile(r"(?:\$newmessage\([\ ]*(?P<delay>[^\"\']+)[\ ]*\))", re.U)
    RegWait = re.compile(r"(?:\$wait\([\ ]*(?P<delay>[^\"\']+)[\ ]*\))", re.U)
    RegCD = re.compile(r"(?:\$cd\([\ ]*(?P<command>[^\"\']+)"
                    r"[\ ]*\,[\ ]*(?P<duration>[^\"\']*)[\ ]*\))", re.U)
    RegUCD = re.compile(r"(?:\$ucd\([\ ]*(?P<command>[^\"\']+)"
                    r"[\ ]*\,[\ ]*(?P<duration>[^\"\']*)[\ ]*\))", re.U)
    # Load in saved settings
    MySet = Settings(settingsFile)
    # End of Init
    return

def Execute(data):
    """Required Execute data function"""
    return
def Tick():
    """Required tick function"""
    return
#---------------------------------------
# System functions
#---------------------------------------
def DoingStuff(message):
    n = 0
    for item in message:
        if "$newmessage(" in item or "$wait(" in item:
            if "$newmessage(" in item:
                resultnm = RegNewmessage.search(item)
            if "$wait(" in item:
                resultnm = RegWait.search(item)
            if resultnm:
                fullParam = resultnm.group(0)
                DelayDuration = resultnm.group("delay")
                if DelayDuration.isdigit():
                   DelayDuration = int(DelayDuration)
                   if DelayDuration > 0:
                        time.sleep(DelayDuration)
                   item = ""
                   message[n] = item
                else:
                    item = "⛔ Error: please enter a number for the delay, by example $wait(5) ⛔ "
                    message[n] = item
            else:
                item = "⛔ Error: please enter a number for the delay, by example $wait(5) ⛔ "
                message[n] = item
        elif "$to(" in item:
            resultto = RegTo.search(item)
            if resultto:
                fullParam = resultto.group(0)
                Username = resultto.group("username")
                ToDuration = resultto.group("duration")
                if ToDuration.isdigit():
                   item = "/timeout " + Username + " " + ToDuration
                   message[n] = item
                else:
                    item = "⛔ Error: please enter a number for the timeout duration, by example $to($username,10) ps: you can use $username/$targetname ⛔ "
                    message[n] = item
            else:
                item = "⛔ Error: please enter a username and number for the timeout, by example $to($targetname,10) ps: you can use $username/$targetname ⛔ "
                message[n] = item
        if not message[n] == "":
            Parent.SendStreamMessage(message[n])
        n += 1
    return

def cd(parseString, parseStringSearch, userid, username):
    infos = {"message":"","cooldown":False,}
    ErrorResultCD = False
    ErrorResultUCD = False
    resultCD = False
    resultUCD = False
    cd = 0
    ucd = 0
    for item in parseStringSearch:
        if "$cd(" in item:
            cd += 1
            resultCD = RegCD.search(item)
            if resultCD:
                if resultCD.group("duration").isdigit():
                    fullParamCD = resultCD.group(0)
                    command = resultCD.group("command")
                    durationCD = int(resultCD.group("duration")) 
                else:
                    ErrorResultCD = True
            else:
                ErrorResultCD = True
        elif "$ucd(" in item:
            ucd += 1
            resultUCD = RegUCD.search(item)
            if resultUCD:
                if resultUCD.group("duration").isdigit():
                    fullParamUCD = resultUCD.group(0)
                    command = resultUCD.group("command")
                    durationUCD = int(resultUCD.group("duration")) 
                else:
                    ErrorResultUCD = True
            else:
                ErrorResultUCD = True
    if cd <= 1 and ucd <= 1:
        if not ErrorResultCD and not ErrorResultUCD:
            caster = (Parent.HasPermission(userid, "Caster", "") and MySet.NoCooldownForCaster)
            if (Parent.IsOnCooldown(ScriptName, command) or Parent.IsOnUserCooldown(ScriptName, command, userid)) and caster is False:
                infos["cooldown"] = True
                parseString = ""
                if MySet.CooldownToggleResp:
                    #set variables 
                    cooldownDuration = Parent.GetCooldownDuration(ScriptName, command)
                    userCDD = Parent.GetUserCooldownDuration(ScriptName, command, userid)
                    if Parent.IsOnCooldown(ScriptName, command) and Parent.IsOnUserCooldown(ScriptName, command, userid):
                        #check for the longest CD and get the message!
                        if cooldownDuration > userCDD:
                            #get cooldown message  and set cooldown duration for the message
                            Message = MySet.OnCooldownResp
                            cooldown = str(cooldownDuration)
                        else: 
                            #get usercooldown message and set cooldown duration for the message
                            Message = MySet.OnUserCooldownResp
                            cooldown = str(userCDD)
                    elif Parent.IsOnCooldown(ScriptName, command) and not Parent.IsOnUserCooldown(ScriptName, command, userid):
                        Message = MySet.OnCooldownResp
                        cooldown = str(cooldownDuration)
                    elif Parent.IsOnUserCooldown(ScriptName, command, userid) and not Parent.IsOnCooldown(ScriptName, command):
                        Message = MySet.OnUserCooldownResp
                        cooldown = str(userCDD)
                    #send message
                    Message = Message.replace("$cooldown", cooldown)
                    Message = Message.replace("$command", command)
                    Message = Message.replace("$user", username)
                    infos["message"] = Message
            elif resultCD and resultUCD:
                Parent.AddCooldown(ScriptName, command, durationCD)
                Parent.AddUserCooldown(ScriptName, command, userid, durationUCD)
                parseString = parseString.replace(fullParamCD, "")
                parseString = parseString.replace(fullParamUCD, "")
                infos["message"] = parseString
            elif resultCD and not resultUCD:
                Parent.AddCooldown(ScriptName, command, durationCD)
                parseString = parseString.replace(fullParamCD, "")
                infos["message"] = parseString
            elif resultUCD and not resultCD:
                Parent.AddUserCooldown(ScriptName, command, userid, durationUCD)
                parseString = parseString.replace(fullParamUCD, "")
                infos["message"] = parseString
        else:
            infos["message"] = "⛔ Error: please enter a command name and a number for $cd() / $ucd() by example $cd(!slap,5) ⛔"
    else:
        infos["message"] = "⛔ Error: you can only have one $ucd() and one $cd() ⛔"
    return infos


#---------------------------------------
# Parse functions
#---------------------------------------
def Parse(parseString, userid, username, targetid, targetname, message):
    global destroy
    global response
    global counter
    parseStringSearch = parseString.split()
    message = [""]
    n = 0
    if ("$cd(" in parseString or "$ucd(" in parseString) and not ("Error: you can only have one $ucd() and one $cd()" in parseString or "Error: please enter a command name and a number for $cd() / $ucd() by example $cd(!slap,5)" in parseString):
        infos = cd(parseString, parseStringSearch, userid, username)
        destroy = infos["cooldown"]
        parseString = infos["message"]
        response = infos["message"]

    if destroy and parseString != response:
        parseString = ""
    
    if ("$to(" in parseString) and not ("Error: please enter a number for the timeout duration, by example $to($username,10) ps: you can use $username/$targetname" in parseString or "$newmessage(" in parseString or "$wait(" in parseString):
        for item in parseStringSearch:
            if "$to(" in item:
                parseString = parseString.replace(item, "")
                message[n] = item
                message.append("")
                n += 1
        threading.Thread(target=DoingStuff, args=(copy.copy(message),)).start()

    if "$newmessage(" in parseString or "$wait(" in parseString:
        counter += 1
        if counter % 5 == 0 and counter > 1:
            parseStringSearch = parseString.split()
            for item in parseStringSearch:
                if "$newmessage(" in item or "$wait(" in item:
                    n += 2
                    message.append(item)
                    message.append("")
                elif "$to(" in item:
                    n += 2
                    message.append(item)
                    message.append("")
                else:
                    message[n] = message[n] + item + " "
            threading.Thread(target=DoingStuff, args=(copy.copy(message),)).start()
            parseString = ""
    return parseString

#---------------------------------------
# UI functions
#---------------------------------------
def OpenReadMe():
    """Open the readme.txt in the scripts folder"""
    location = os.path.join(os.path.dirname(__file__), "README.txt")
    os.startfile(location)