###################
#  Time Master    #
###################

Description: Extra $parameters
Made By: Must13
Website: https://www.twitch.tv/must13

#############################
#         Versions          #
#############################

	1.0.4 
		- Every chatbot's parameters And other scripts' parameters are now compatible with the $wait() parameter, they will work but won't be delayed, only their chat response will be.
	1.0.3 
		- Fixed $cd()/$ucd() when used in a multi lines command's response
	1.0.2 
		- added $wait() to replace $newmessage(), $newmessage() is still working but $wait() is preferred
	1.0.1 
		- $to() will not force the rest of the message to be sent to stream chat anymore
		- $to() will now respect the delay set in $newmessage()
    1.0.0 
        - Initial release

#############################
#      New  Parameters      #
#############################

$wait(delay)					- will send the next part of the response after the delay in a new message, you can use as many as you want. NOTE 1
$to(username,duration)			- will time out username for duration, you can use as many as you want.
$cd(Command name,duration)		- will apply a cooldown in second to the command, you can only use one per command's response. NOTE 2
$ucd(command name,duration)		- will apply a user cooldown in second to the command, you can only use one per command's response. NOTE 2

NOTE 1: it will send it to the stream chat, so far i can't determine where the !command is used.
NOTE 2: these cooldowns only work if you have the parameter $cd() or $ucd() in the response with the specified command's name.

#############################
#     Example Commands      #
#############################

$wait(0)                  - will delay the next part of the response for 0 sec, i wanted to mention this because it's a nice way to create a command from chat with multiple responses and no delay
$wait(5)                  - will delay the next part of the response for 5 sec

$to($username,10)               - will timeout the user of the command for 10 sec
$to($targetname,10)             - will timeout the targeted user for 10 sec
$to($targetname,$num2)          - will timeout the targeted user for the specified amount of time in sec

$cd(!slap,10)                   - will apply a cooldown on the specified command for 10 sec

$ucd(!slap,15)                  - will apply a user cooldown on the specified command for 15 sec

