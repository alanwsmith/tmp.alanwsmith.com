#!/usr/bin/python
# -*- coding: utf-8 -*-
#Parent = Parent # pylint: disable=invalid-name
"""Store script to purchase rewards for users"""
#---------------------------------------
# Libraries and references
#---------------------------------------
import codecs
import json
import os
import datetime
import ctypes
import winsound

#---------------------------------------
# Script information
#---------------------------------------
ScriptName = "Playlist Exporter"
Website = "https://www.twitch.tv/Xailran"
Creator = "Xailran"
Version = "1.0.0"
Description = "Export all the URLs in your songlist into a .txt, for easy use and modification!"

#---------------------------------------
# Versions
#---------------------------------------
"""
1.0.0 - Initial Release!
"""

#---------------------------------------
# Variables
#---------------------------------------
settingsFile = os.path.join(os.path.dirname(__file__), "settings.json")
MessageBox = ctypes.windll.user32.MessageBoxW
MB_YES = 6

#---------------------------------------
# Settings functions
#---------------------------------------
def SetDefaults():
	"""Set default settings function"""
	winsound.MessageBeep()
	returnValue = MessageBox(0, u"You are about to reset the settings, "
								"are you sure you want to continue?"
							 , u"Reset settings file?", 4)

	if returnValue == MB_YES:
		Settings(None, None).Save(settingsFile)
		MessageBox(0, u"Settings successfully restored to default values!"
					  "\r\nMake sure to reload script to load new values into UI"
				   , u"Reset complete!", 0)

def ReloadSettings(jsonData):
	"""Reload settings on Save"""
	global MySet
	MySet.Reload(jsonData)

#---------------------------------------
# UI functions
#---------------------------------------
def OpenReadMe():
	"""Open the readme.txt in the scripts folder"""
	location = os.path.join(os.path.dirname(__file__), "README.txt")
	os.startfile(location)

def OpenFolder():
	"""Open Store Script Folder"""
	location = (os.path.dirname(os.path.realpath(__file__)))
	os.startfile(location)

def ExportPlaylist():
	"""Save playlist, and then open it"""
	PlaylistProcess()
	location = os.path.join(os.path.dirname(__file__), MySet.playlistname + ".txt")
	os.startfile(location)

#---------------------------------------
# Optional functions
#---------------------------------------
def HasPermission(data, permission, permissioninfo):
    """Return true or false dending on if the user has permission.
    Also sends permission response if user doesn't"""
    if not Parent.HasPermission(data.User, permission, permissioninfo):
        message = MySet.notperm.format(data.UserName, permission, permissioninfo)
        Parent.SendStreamMessage(message)
        return False
    return True

#---------------------------------------
# [Required] functions
#---------------------------------------
def Init():
	"""data on Load, required function"""
	global MySet
	MySet = Settings(Parent, settingsFile)
	global parent
	parent = Parent

def Execute(data):
	"""Required Execute data function"""
	#Solo command for exporting playlist
	if data.GetParam(0).lower() == MySet.command.lower():
		if not HasPermission(data, MySet.permission, MySet.permissioninfo):
			return
		PlaylistProcess()
		
def Tick():
	"""Required Tick function"""
	return

#---------------------------------------
# [Optional] Script functions
#---------------------------------------
def PlaylistProcess():
	number = 100
	songs = Parent.GetSongPlaylist(number)
	while len(songs) == number:
		number += 100
		songs = Parent.GetSongPlaylist(number)
	Parent.SendStreamMessage("Songlist length set at " + str(len(songs)) + " songs.")
	File = os.path.join(os.path.dirname(__file__), MySet.playlistname + ".txt")
	if os.path.exists(File):
		Parent.SendStreamMessage("The file {0}.txt is already taken! Please set another file in the UI".format(MySet.playlistname))
		return
	for obj in songs:
		textline = obj.URL
		with codecs.open(File, "a", "utf-8") as f:
			f.write(u"" + textline + "\r\n")
	Parent.SendStreamMessage("Playlist has been exported!")
#---------------------------------------
# Classes
#---------------------------------------
class Settings:
	""" Loads settings from file if file is found if not uses default values"""

	# The 'default' variable names need to match UI_Config
	def __init__(self, parent, settingsFile=None):
		if settingsFile and os.path.isfile(settingsFile):
			with codecs.open(settingsFile, encoding='utf-8-sig', mode='r') as f:
				self.__dict__ = json.load(f, encoding='utf-8-sig')
		else: #set variables if no custom settings file is found
			self.playlistname = "playlist"
			self.command = "!export"
			self.notperm = "{0} -> you don't have permission to use this command. permission is: [{1} / {2}]"
			self.permission = "Caster"
			self.permissioninfo = ""

		self.parent = parent

	# Reload settings on save through UI
	def Reload(self, data):
		"""Reload settings on save through UI"""
		parent = self.parent
		self.__dict__ = json.loads(data, encoding='utf-8-sig')
		self.parent = parent
	
	def Save(self, settingsfile):
		""" Save settings contained within the .json and .js settings files. """
		try:
			with codecs.open(settingsfile, encoding="utf-8-sig", mode="w+") as f:
				json.dump(self.__dict__, f, encoding="utf-8", ensure_ascii=False)
			with codecs.open(settingsfile.replace("json", "js"), encoding="utf-8-sig", mode="w+") as f:
				f.write("var settings = {0};".format(json.dumps(self.__dict__, encoding='utf-8', ensure_ascii=False)))
		except ValueError:
			MessageBox(0, u"Settings failed to save to file"
					   , u"Saving failed", 0)