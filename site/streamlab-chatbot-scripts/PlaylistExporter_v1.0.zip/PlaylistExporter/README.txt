###############################
#   Songlist Export Script    #
###############################

Description: Export all the URLs in your songlist into a .txt, for easy use and modification!
Made By: Xailran
Websites: https://www.twitch.tv/xailran
	  https://www.twitter.com/xailran

#####################
#     Versions      #
#####################

1.0.0 - Initial Release

Known bugs:
None

#####################
#       Usage       #
#####################
Just use the !export command once in chat (or whatever you set the command to), and bam, your songlist has been exported!
Songs don't need to be playing, you just need to have the songlist loaded. If you have played songs from your songlist, you won't get the whole list exported.
Or, you can just press the fancy button in your UI, and the script will do its thing!
Error messages will be sent in chat either way though.

######################
#   Future Updates   #
######################
- Change error messages to be visible in pop-up window when using button for exporting playlist

################################
#   Other Scripts by Xailran   #
################################
Please note that commissioned scripts come with idea and sale protection. These scripts are not included in the list below
Idea protection means that I will not share any ideas without permission from the client.
Sale protection means that I will not give away a script for free that someone else has paid for, without permission from the original client.
Existing clients are able to request early release versions of public scripts. If you would like to commission a script, send me a message on Discord!

Public Scripts:
Store (1.5.1) (2.0.0 coming out soon!)
Songlist Exporter (1.0.0)
Fight (soon)
The Song Didn't Play (in development)
Total Points (in planning)
StayHydrated, chatbot edition (in planning)

Up to date as of 5/12/2018

#############################################
#   Donations are never expected, but any   #
#    support definitely helps, and keeps    #
#     me able to make more free scripts!    #
#       https://streamlabs.com/xailran      # 
#############################################
#############################################
# Tag me in the Streamlabs Chatbot discord  #
#    if you have any questions or ideas!    #
#   https://discordapp.com/invite/J4QMG5m   #
#############################################